#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    service.SetCommunication("192.168.60.16");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_write_clicked()
{
//    int i = ui->lineEdit->text().toInt();
//    int result = 0;
//    service.XNETWrite(XNET_HD,0,2,&i,result);
    short i = ui->lineEdit->text().toShort();
    short a[1] = {i};
    service.WriteRegs(XNet_HD,0,1,a);
}

void MainWindow::on_pushButton_read_clicked()
{
//    int i;
//    int result = 0;
//    service.XNETRead(XNET_HD,0,2,&i,result);
    short a[1];
    service.ReadRegs(XNet_HD,0,1,a);
    short i = a[0];
    ui->label->setText(QString::number(i) );
}
